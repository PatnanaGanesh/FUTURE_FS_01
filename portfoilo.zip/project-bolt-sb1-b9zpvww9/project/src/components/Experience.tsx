import React from 'react';
import { Calendar, MapPin, Briefcase } from 'lucide-react';

const Experience: React.FC = () => {
  const experiences = [
    {
      title: "Computer Science Student",
      company: "Chalapathi Institute of Engineering and Technology",
      location: "Andhra Pradesh, India",
      duration: "Oct 2022 - Present",
      description: [
        "Currently pursuing B.Tech in Computer Science and Information Technology",
        "Maintaining CGPA of 7.14/10.0 with focus on web development",
        "Developing expertise in MERN stack technologies",
        "Building responsive web applications as part of coursework and personal projects"
      ],
      technologies: ["HTML", "CSS", "JavaScript", "React.js", "Node.js", "MongoDB"]
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gradient-to-br from-violet-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Academic <span className="text-violet-600">Journey</span>
          </h2>
          <div className="w-20 h-1 bg-violet-600 mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            My academic journey and learning path in computer science and web development
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-violet-600 hidden md:block"></div>
            
            {experiences.map((exp, index) => (
              <div key={index} className="relative mb-12 md:ml-16">
                <div className="absolute -left-20 top-6 w-4 h-4 bg-violet-600 rounded-full border-4 border-white shadow-lg hidden md:block"></div>
                
                <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-8 transform hover:-translate-y-1 border border-violet-100">
                  <div className="flex flex-wrap justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-2">{exp.title}</h3>
                      <div className="flex items-center text-violet-600 mb-2">
                        <Briefcase size={16} className="mr-2" />
                        <span className="font-semibold">{exp.company}</span>
                      </div>
                    </div>
                    <div className="text-right text-gray-600">
                      <div className="flex items-center mb-1">
                        <Calendar size={16} className="mr-2" />
                        <span>{exp.duration}</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin size={16} className="mr-2" />
                        <span>{exp.location}</span>
                      </div>
                    </div>
                  </div>

                  <ul className="space-y-2 mb-6">
                    {exp.description.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-start text-gray-600">
                        <span className="w-2 h-2 bg-violet-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                        {item}
                      </li>
                    ))}
                  </ul>

                  <div className="flex flex-wrap gap-2">
                    {exp.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-3 py-1 bg-violet-100 text-violet-800 rounded-full text-sm font-medium"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;