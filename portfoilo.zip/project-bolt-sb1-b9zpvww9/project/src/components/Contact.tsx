import GaneshImg from '../image/Ganesh.jpg';
import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Github, Linkedin } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
    alert('Thank you for your message! I will get back to you soon.');
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-navy-900 via-violet-900 to-indigo-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Get In <span className="text-violet-400">Touch</span>
          </h2>
          <div className="w-20 h-1 bg-violet-400 mx-auto mb-6"></div>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Let's connect and discuss web development opportunities or collaborate on exciting projects. 
            I'm always eager to learn and contribute to innovative solutions.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Information & Profile */}
          <div className="space-y-8">
            {/* Profile Card */}
            <div className="bg-navy-800/80 backdrop-blur-sm rounded-xl p-8 shadow-xl border border-violet-500/20">
              <div className="text-center mb-8">
                <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-violet-500 to-violet-600 flex items-center justify-center">
                  <img
                    src={GaneshImg}
                    alt="Patnana Ganesh"
                    className="w-28 h-28 rounded-full object-cover border-4 border-white shadow-lg"
                  />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Patnana Ganesh</h3>
                <p className="text-violet-400 font-semibold">Computer Science Student & MERN Stack Developer</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-4 text-gray-300">
                  <Mail size={20} className="text-violet-400" />
                  <span>ganeshpatnana195@gmail.com</span>
                </div>
                <div className="flex items-center space-x-4 text-gray-300">
                  <Phone size={20} className="text-violet-400" />
                  <span>+91 9553226230</span>
                </div>
                <div className="flex items-center space-x-4 text-gray-300">
                  <MapPin size={20} className="text-violet-400" />
                  <span>Murukuntibadra, Andhra Pradesh</span>
                </div>
              </div>

              <div className="flex justify-center space-x-4 mt-8 pt-8 border-t border-gray-700">
                <a
                  href="https://github.com/PatnanaGanesh"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-gray-700 hover:bg-violet-600 rounded-full transition-all duration-300 transform hover:scale-110"
                >
                  <Github size={20} className="text-white" />
                </a>
                <a
                  href="https://linkedin.com/in/patnana-ganesh/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-gray-700 hover:bg-violet-600 rounded-full transition-all duration-300 transform hover:scale-110"
                >
                  <Linkedin size={20} className="text-white" />
                </a>
                <a
                  href="mailto:ganeshpatnana195@gmail.com"
                  className="p-3 bg-gray-700 hover:bg-violet-600 rounded-full transition-all duration-300 transform hover:scale-110"
                >
                  <Mail size={20} className="text-white" />
                </a>
              </div>
            </div>

            {/* Quick Info */}
            <div className="bg-navy-800/80 backdrop-blur-sm rounded-xl p-6 shadow-xl border border-violet-500/20">
              <h4 className="text-xl font-bold text-white mb-4">Let's Collaborate</h4>
              <p className="text-gray-300 mb-4">
                I'm currently seeking internship opportunities and freelance web development projects. 
                Whether you need a responsive website, e-commerce platform, or web application, 
                I'm excited to help bring your ideas to life.
              </p>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-navy-700 rounded-lg p-3">
                  <div className="text-2xl font-bold text-violet-400">2+</div>
                  <div className="text-gray-300 text-sm">Projects Completed</div>
                </div>
                <div className="bg-navy-700 rounded-lg p-3">
                  <div className="text-2xl font-bold text-violet-400">7.14</div>
                  <div className="text-gray-300 text-sm">CGPA</div>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div>
            <div className="bg-navy-800/80 backdrop-blur-sm rounded-xl p-8 shadow-xl border border-violet-500/20">
              <h3 className="text-2xl font-bold text-white mb-6">Send Me a Message</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-gray-300 font-semibold mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-navy-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-400/50 transition-all duration-300"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-gray-300 font-semibold mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-navy-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-400/50 transition-all duration-300"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-gray-300 font-semibold mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 bg-navy-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-400/50 transition-all duration-300"
                    placeholder="Project Inquiry"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-gray-300 font-semibold mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 bg-navy-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-400/50 transition-all duration-300 resize-none"
                    placeholder="Tell me about your project or how I can help you..."
                  ></textarea>
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-violet-600 hover:bg-violet-700 text-white font-semibold py-4 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 shadow-lg"
                >
                  <Send size={20} />
                  <span>Send Message</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;