import React from 'react';
import { Heart, Code } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-r from-navy-950 via-violet-950 to-indigo-950 py-8">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-gray-300 flex items-center">
              Made with <Heart size={16} className="text-red-500 mx-2" /> and <Code size={16} className="text-violet-400 mx-2" /> by Patnana Ganesh
            </p>
          </div>
          <div className="text-gray-400 text-sm">
            © {currentYear} Patnana Ganesh. All rights reserved. Built with React & TypeScript.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;