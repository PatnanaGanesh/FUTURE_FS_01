import React from 'react';
import { GraduationCap, Award, Calendar } from 'lucide-react';

const Education: React.FC = () => {
  const education = [
    {
      degree: "Bachelor of Technology in Computer Science and Information Technology",
      school: "Chalapathi Institute of Engineering and Technology",
      location: "Andhra Pradesh, India",
      duration: "Oct 2022 - Mar 2026",
      gpa: "7.14/10.0",
      description: "Currently pursuing B.Tech with focus on web development and software engineering",
      achievements: [
        "Strong foundation in programming languages",
        "Specialized in MERN stack development",
        "Focus on responsive web design and development"
      ]
    }
  ];

  const certifications = [
    {
      name: "Web Development Fundamentals",
      issuer: "Self-Learning",
      date: "2024",
      credentialId: "WDF-2024-001"
    }
  ];

  return (
    <section id="education" className="py-20 bg-gradient-to-br from-violet-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Education & <span className="text-violet-600">Learning</span>
          </h2>
          <div className="w-20 h-1 bg-violet-600 mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            My academic background and continuous learning journey in computer science and web development
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Education Section */}
          <div>
            <h3 className="text-2xl font-bold text-gray-800 mb-8 flex items-center">
              <GraduationCap className="mr-3 text-violet-600" size={28} />
              Academic Background
            </h3>
            
            <div className="space-y-8">
              {education.map((edu, index) => (
                <div
                  key={index}
                  className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-8 transform hover:-translate-y-1 border border-violet-100"
                >
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4">
                    <div className="mb-4 md:mb-0">
                      <h4 className="text-xl font-bold text-gray-800 mb-2">{edu.degree}</h4>
                      <p className="text-violet-600 font-semibold mb-1">{edu.school}</p>
                      <p className="text-gray-600">{edu.location}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center text-gray-600 mb-1">
                        <Calendar size={16} className="mr-2" />
                        <span>{edu.duration}</span>
                      </div>
                      <div className="text-violet-600 font-semibold">CGPA: {edu.gpa}</div>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4">{edu.description}</p>
                  
                  <div>
                    <h5 className="font-semibold text-gray-800 mb-2">Key Achievements:</h5>
                    <ul className="space-y-1">
                      {edu.achievements.map((achievement, achievementIndex) => (
                        <li key={achievementIndex} className="flex items-start text-gray-600">
                          <span className="w-2 h-2 bg-violet-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications Section */}
          <div>
            <h3 className="text-2xl font-bold text-gray-800 mb-8 flex items-center">
              <Award className="mr-3 text-violet-600" size={28} />
              Learning & Development
            </h3>
            
            <div className="space-y-6">
              {certifications.map((cert, index) => (
                <div
                  key={index}
                  className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 transform hover:-translate-y-1 border border-violet-100"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-gray-800 mb-2">{cert.name}</h4>
                      <p className="text-violet-600 font-semibold mb-1">{cert.issuer}</p>
                      <p className="text-gray-600 text-sm mb-2">Credential ID: {cert.credentialId}</p>
                    </div>
                    <div className="text-right ml-4">
                      <span className="inline-flex items-center px-3 py-1 bg-violet-100 text-violet-800 rounded-full text-sm font-medium">
                        {cert.date}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Additional Skills */}
            <div className="mt-12 bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-8 border border-violet-100">
              <h4 className="text-lg font-bold text-gray-800 mb-6">Technical Focus Areas</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h5 className="font-semibold text-gray-700 mb-2">Core Technologies</h5>
                  <ul className="text-gray-600 text-sm space-y-1">
                    <li>• MERN Stack Development</li>
                    <li>• Responsive Web Design</li>
                    <li>• JavaScript ES6+</li>
                    <li>• RESTful API Development</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-semibold text-gray-700 mb-2">Development Skills</h5>
                  <ul className="text-gray-600 text-sm space-y-1">
                    <li>• Cross-browser Compatibility</li>
                    <li>• Mobile-first Design</li>
                    <li>• Modern CSS Techniques</li>
                    <li>• Version Control (Git)</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;