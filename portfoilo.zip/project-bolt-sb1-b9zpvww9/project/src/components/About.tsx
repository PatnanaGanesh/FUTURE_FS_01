import React from 'react';
import { Code, Server, Database, Smartphone } from 'lucide-react';

const About: React.FC = () => {
  const highlights = [
    {
      icon: <Code size={24} />,
      title: "Frontend Development",
      description: "React, Angular, Vue.js, TypeScript"
    },
    {
      icon: <Server size={24} />,
      title: "Backend Development", 
      description: "Node.js, Python, Java, REST APIs"
    },
    {
      icon: <Database size={24} />,
      title: "Database Management",
      description: "MongoDB, PostgreSQL, MySQL"
    },
    {
      icon: <Smartphone size={24} />,
      title: "Mobile Development",
      description: "React Native, Flutter"
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-violet-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            About <span className="text-violet-600">Me</span>
          </h2>
          <div className="w-20 h-1 bg-violet-600 mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800">
              Computer Science Student & MERN Stack Developer
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Currently pursuing B.Tech in Computer Science and Information Technology at 
              Chalapathi Institute of Engineering and Technology. I specialize in creating 
              responsive web applications using the MERN stack and modern JavaScript technologies.
            </p>
            <p className="text-gray-600 leading-relaxed">
              I'm passionate about web development and creating user-friendly interfaces. 
              My goal is to build innovative solutions that provide exceptional user experiences 
              while maintaining clean, efficient code and following best practices.
            </p>
            
            <div className="pt-4">
              <h4 className="text-xl font-semibold text-gray-800 mb-4">Key Strengths</h4>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-violet-600 rounded-full mr-3"></span>
                  Problem-solving and analytical thinking
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-violet-600 rounded-full mr-3"></span>
                  Responsive web design and development
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-violet-600 rounded-full mr-3"></span>
                  Cross-browser compatibility
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-violet-600 rounded-full mr-3"></span>
                  Continuous learning and adaptation
                </li>
              </ul>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {highlights.map((item, index) => (
              <div
                key={index}
                className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-violet-100"
              >
                <div className="text-violet-600 mb-4">{item.icon}</div>
                <h4 className="text-lg font-semibold text-gray-800 mb-2">{item.title}</h4>
                <p className="text-gray-600 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;